# 🎂 Happy Birthday Aati — Interactive Surprise Website

A premium, single-page birthday surprise site. Pure HTML/CSS/JS — no frameworks, no build step.

## How to run it
Just open `index.html` in a browser, or serve the folder with any static server.

## How to add the real photos
Replace the 6 placeholder gradient images in `images/` with real photos, **keeping the same file names**:
```
images/1.jpg
images/2.jpg
images/3.jpg
images/4.jpg
images/5.jpg
images/6.jpg
```
Square photos (or close to square) will look best in the gallery frames.

## How to add the birthday music
Drop an MP3 named `birthday.mp3` into the `music/` folder:
```
music/birthday.mp3
```
The site will try to autoplay it in a loop the instant the page loads. Most browsers block autoplay with sound until the visitor interacts with the page — the script already handles this by starting playback on the very first click, tap, or key press if autoplay was blocked. A 🎵 button (top-right) also lets the birthday person mute/unmute manually.

## Folder structure
```
index.html      -> the four surprise screens
style.css       -> theme, glassmorphism, all animations
script.js       -> navigation, typewriter, particles, confetti, fireworks, music
images/         -> the 6 gallery photos
music/          -> birthday.mp3
```

## Customizing the flow
- The letter text lives in the `letterLines` array near the top of `script.js` — edit freely, the typewriter reflows automatically.
- Screen order and buttons are wired through `data-next="N"` attributes in `index.html`.
- Colors and fonts are CSS custom properties at the top of `style.css` (`:root`) — change once, updates everywhere.

Made with love for a very special birthday.
