/* =====================================================================
   HAPPY BIRTHDAY AATI — script.js
   Vanilla JS only. Organized into small focused modules:
     1. Loader
     2. Screen navigation
     3. Ambient floating hearts & sparkles
     4. Typewriter letter animation
     5. Background music (autoplay + unlock fallback)
     6. Gallery (already animated by CSS — no JS needed there)
     7. Final celebration: confetti, fireworks, balloons
     8. Replay
   ===================================================================== */

document.addEventListener('DOMContentLoaded', () => {

  /* -------------------------------------------------------------
     1. LOADER — premium "Loading your surprise..." screen
     ------------------------------------------------------------- */
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => loader.classList.add('hide'), 1600);
  });
  // Fallback in case 'load' already fired or is slow to fire
  setTimeout(() => loader.classList.add('hide'), 3200);

  /* -------------------------------------------------------------
     2. SCREEN NAVIGATION — data-next="N" drives which screen shows
     ------------------------------------------------------------- */
  const screens = Array.from(document.querySelectorAll('.screen'));

  function goToScreen(num){
    const target = document.getElementById('screen-' + num);
    if(!target) return;

    screens.forEach(s => {
      if(s === target) return;
      if(s.classList.contains('active')){
        s.classList.add('leaving');
        s.classList.remove('active');
        setTimeout(() => s.classList.remove('leaving'), 1000);
      }
    });

    target.classList.add('active');

    // Trigger screen-specific entrance behavior
    if(num === '2' || num === 2) startTypewriter();
    if(num === '4' || num === 4) startCelebration();
  }

  document.querySelectorAll('[data-next]').forEach(btn => {
    btn.addEventListener('click', () => goToScreen(btn.getAttribute('data-next')));
  });

  /* -------------------------------------------------------------
     3. AMBIENT FLOATING HEARTS & SPARKLES — runs continuously
     ------------------------------------------------------------- */
  const floatersEl = document.getElementById('floaters');
  const heartGlyphs = ['💜', '💗', '💖', '💕', '💞'];
  const sparkleGlyphs = ['✨', '⭐', '✦'];

  function spawnFloater(){
    const isHeart = Math.random() > 0.45;
    const el = document.createElement('span');
    el.className = 'floater ' + (isHeart ? 'heart' : 'sparkle');
    el.textContent = isHeart
      ? heartGlyphs[Math.floor(Math.random() * heartGlyphs.length)]
      : sparkleGlyphs[Math.floor(Math.random() * sparkleGlyphs.length)];

    const size = isHeart ? (14 + Math.random() * 20) : (10 + Math.random() * 12);
    const left = Math.random() * 100;
    const duration = 9 + Math.random() * 10;
    const drift = (Math.random() * 140 - 70) + 'px';

    el.style.left = left + 'vw';
    el.style.fontSize = size + 'px';
    el.style.setProperty('--drift', drift);
    el.style.animationDuration = duration + 's';

    floatersEl.appendChild(el);
    setTimeout(() => el.remove(), duration * 1000 + 200);
  }

  // Gentle continuous ambience across every screen
  setInterval(spawnFloater, 650);
  for(let i = 0; i < 6; i++) setTimeout(spawnFloater, i * 220);

  /* -------------------------------------------------------------
     4. TYPEWRITER — the heartfelt letter, typed line by line
     ------------------------------------------------------------- */
  const letterLines = [
    "Happy Birthday, Aati! ❤️🎂",
    "",
    "Today is a very special day because it's the day you came into this world.",
    "",
    "May Allah fill your life with happiness, peace, success, endless blessings and beautiful memories.",
    "May every dream of yours come true.",
    "May your smile always stay as beautiful as it is today.",
    "",
    "Never forget how special and valuable you are.",
    "Thank you for being such a wonderful person.",
    "",
    "I pray that Allah always protects you, guides you and keeps you smiling forever.",
    "May every birthday be happier than the last one.",
    "",
    "Stay Happy.",
    "Stay Blessed.",
    "Stay Beautiful.",
    "",
    "Once Again...",
    "🎉 HAPPY BIRTHDAY AATI 🎉",
    "",
    "With Best Wishes,",
    "❤️ Asad ❤️"
  ];

  const typewriterEl = document.getElementById('typewriter');
  const letterNextBtn = document.getElementById('letter-next-btn');
  let typewriterStarted = false;

  function startTypewriter(){
    if(typewriterStarted) return;
    typewriterStarted = true;

    typewriterEl.innerHTML = '';
    const cursor = document.createElement('span');
    cursor.className = 'cursor';
    cursor.textContent = '\u00A0';

    let lineIndex = 0;
    let charIndex = 0;
    let currentLineEl = null;

    function typeStep(){
      if(lineIndex >= letterLines.length){
        cursor.remove();
        letterNextBtn.classList.add('ready');
        return;
      }

      const line = letterLines[lineIndex];

      if(charIndex === 0){
        currentLineEl = document.createElement('div');
        typewriterEl.appendChild(currentLineEl);
        typewriterEl.appendChild(cursor);
      }

      if(line === ''){
        // Blank line = paragraph break, no typing needed
        lineIndex++;
        charIndex = 0;
        setTimeout(typeStep, 260);
        return;
      }

      currentLineEl.textContent = line.slice(0, charIndex + 1);
      charIndex++;

      if(charIndex >= line.length){
        lineIndex++;
        charIndex = 0;
        setTimeout(typeStep, 380); // pause between lines
      } else {
        setTimeout(typeStep, 26); // typing speed per character
      }
    }

    typeStep();
  }

  /* -------------------------------------------------------------
     5. BACKGROUND MUSIC — autoplay, with unlock-on-interaction
     ------------------------------------------------------------- */
  const music = document.getElementById('bg-music');
  const musicToggle = document.getElementById('music-toggle');
  let musicUnlocked = false;

  function tryPlayMusic(){
    const playPromise = music.play();
    if(playPromise !== undefined){
      playPromise.then(() => {
        musicUnlocked = true;
        musicToggle.classList.remove('muted');
      }).catch(() => {
        // Autoplay blocked — wait for first user interaction
        musicToggle.classList.add('muted');
      });
    }
  }

  tryPlayMusic();

  function unlockMusicOnce(){
    if(musicUnlocked) return;
    music.play().then(() => {
      musicUnlocked = true;
      musicToggle.classList.remove('muted');
    }).catch(() => {});
  }
  ['click', 'touchstart', 'keydown'].forEach(evt => {
    document.addEventListener(evt, unlockMusicOnce, { once: true });
  });

  musicToggle.addEventListener('click', () => {
    if(music.paused){
      music.play();
      musicToggle.classList.remove('muted');
    } else {
      music.pause();
      musicToggle.classList.add('muted');
    }
  });

  /* -------------------------------------------------------------
     6. FINAL CELEBRATION — confetti + fireworks + balloons
     ------------------------------------------------------------- */
  const confettiCanvas = document.getElementById('confetti-canvas');
  const fireworksCanvas = document.getElementById('fireworks-canvas');
  const confettiCtx = confettiCanvas.getContext('2d');
  const fireworksCtx = fireworksCanvas.getContext('2d');
  const balloonsEl = document.getElementById('balloons');

  let confettiPieces = [];
  let fireworkParticles = [];
  let animationRunning = false;
  let celebrationStarted = false;

  const confettiColors = ['#ff4fa3', '#ffd76a', '#d9b8ff', '#9b6bff', '#ff8fc7', '#ffffff'];

  function resizeCanvases(){
    [confettiCanvas, fireworksCanvas].forEach(c => {
      c.width = window.innerWidth;
      c.height = window.innerHeight;
    });
  }
  window.addEventListener('resize', resizeCanvases);

  function createConfettiBurst(count){
    for(let i = 0; i < count; i++){
      confettiPieces.push({
        x: Math.random() * confettiCanvas.width,
        y: -20 - Math.random() * confettiCanvas.height * 0.4,
        w: 6 + Math.random() * 6,
        h: 10 + Math.random() * 8,
        color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
        speedY: 2 + Math.random() * 3,
        speedX: (Math.random() - 0.5) * 2,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 8
      });
    }
  }

  function launchFirework(){
    const x = confettiCanvas.width * (0.15 + Math.random() * 0.7);
    const y = fireworksCanvas.height * (0.2 + Math.random() * 0.35);
    const color = confettiColors[Math.floor(Math.random() * confettiColors.length)];
    const particleCount = 44;

    for(let i = 0; i < particleCount; i++){
      const angle = (Math.PI * 2 * i) / particleCount;
      const speed = 2 + Math.random() * 3;
      fireworkParticles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        life: 60 + Math.random() * 20,
        age: 0
      });
    }
  }

  function renderLoop(){
    if(!animationRunning) return;

    confettiCtx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    fireworksCtx.clearRect(0, 0, fireworksCanvas.width, fireworksCanvas.height);

    // --- confetti ---
    confettiPieces.forEach(p => {
      p.y += p.speedY;
      p.x += p.speedX;
      p.rotation += p.rotationSpeed;

      confettiCtx.save();
      confettiCtx.translate(p.x, p.y);
      confettiCtx.rotate((p.rotation * Math.PI) / 180);
      confettiCtx.fillStyle = p.color;
      confettiCtx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      confettiCtx.restore();
    });
    confettiPieces = confettiPieces.filter(p => p.y < confettiCanvas.height + 40);

    // --- fireworks ---
    fireworkParticles.forEach(p => {
      p.age++;
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.045; // gravity

      const alpha = Math.max(0, 1 - p.age / p.life);
      fireworksCtx.beginPath();
      fireworksCtx.fillStyle = p.color;
      fireworksCtx.globalAlpha = alpha;
      fireworksCtx.arc(p.x, p.y, 2.6, 0, Math.PI * 2);
      fireworksCtx.fill();
      fireworksCtx.globalAlpha = 1;
    });
    fireworkParticles = fireworkParticles.filter(p => p.age < p.life);

    requestAnimationFrame(renderLoop);
  }

  function spawnBalloon(){
    const colors = ['#ff4fa3', '#9b6bff', '#ffd76a', '#ff8fc7', '#d9b8ff'];
    const el = document.createElement('div');
    el.className = 'balloon';
    const left = Math.random() * 90;
    const duration = 10 + Math.random() * 8;
    const drift = (Math.random() * 120 - 60) + 'px';
    const color = colors[Math.floor(Math.random() * colors.length)];

    el.style.left = left + 'vw';
    el.style.background = `radial-gradient(circle at 35% 30%, rgba(255,255,255,0.55), ${color} 70%)`;
    el.style.animationDuration = duration + 's';
    el.style.setProperty('--drift', drift);

    balloonsEl.appendChild(el);
    setTimeout(() => el.remove(), duration * 1000 + 200);
  }

  let fireworkInterval, balloonInterval, confettiInterval;

  function startCelebration(){
    if(celebrationStarted) return;
    celebrationStarted = true;

    resizeCanvases();
    confettiCanvas.style.display = 'block';
    fireworksCanvas.style.display = 'block';
    animationRunning = true;
    renderLoop();

    // Initial big bursts
    createConfettiBurst(160);
    launchFirework();
    setTimeout(launchFirework, 500);
    setTimeout(launchFirework, 1000);

    // Ongoing ambience
    confettiInterval = setInterval(() => createConfettiBurst(30), 1400);
    fireworkInterval = setInterval(launchFirework, 1800);
    balloonInterval = setInterval(spawnBalloon, 900);
    for(let i = 0; i < 5; i++) setTimeout(spawnBalloon, i * 300);
  }

  function stopCelebration(){
    celebrationStarted = false;
    animationRunning = false;
    clearInterval(confettiInterval);
    clearInterval(fireworkInterval);
    clearInterval(balloonInterval);
    confettiPieces = [];
    fireworkParticles = [];
    confettiCanvas.style.display = 'none';
    fireworksCanvas.style.display = 'none';
    balloonsEl.innerHTML = '';
  }

  /* -------------------------------------------------------------
     8. REPLAY — resets celebration and returns to Screen 1
     ------------------------------------------------------------- */
  const replayBtn = document.getElementById('replay-btn');
  replayBtn.addEventListener('click', () => {
    stopCelebration();

    // Reset the letter so the typewriter can play again
    typewriterStarted = false;
    letterNextBtn.classList.remove('ready');
    typewriterEl.innerHTML = '';

    goToScreen(1);
  });

});
